﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionExamples
{
    class Employee
    {
        public int empId;
        public string empName;

        public Employee(int empId, string empName)
        {
            this.empId = empId;
            this.empName = empName;
        }

        public override string ToString()
        {
            return $"EmpId : {empId}; Emp Name : {empName}";
        }
    }
    class Program
    {
        static void displayVariant1(ArrayList arr)
        {
            foreach (var item in arr)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();
            al.Add(100);
            al.Add(100.56);
            al.Add("hello");
            al.Add(true);
            al.Add(new int[] { 10, 20, 30 });
            displayVariant1(al);

            Console.WriteLine("Count of elements in the array list" + al.Count);
            Console.WriteLine("Capacity of the array list" + al.Capacity);
            Console.WriteLine("Is the array list read only" + al.IsReadOnly);

            // add some elements at a particular position
            al.Insert(2, 999);

            // add a range of values at the end
            ArrayList colours = new ArrayList() { "red","blue","pink"};
            al.AddRange(colours);// will append 

            // add a range of values at a particular position
            ArrayList fruits = new ArrayList() { "apple", "bananas", "mangoes" };
            al.InsertRange(0,fruits);// will append 
            displayVariant1(al);
            Console.WriteLine("Count of elements in the array list" + al.Count);
            Console.WriteLine("Capacity of the array list" + al.Capacity);
            Console.WriteLine("Is the array list read only" + al.IsReadOnly);

            // remove the last element -- pop -- from the end
            al.RemoveAt(al.Count - 1);
            displayVariant1(al);

            // remove on basis of value
            al.Remove("hello");
            displayVariant1(al);

            // remove multiple elements based on the position
            al.RemoveRange(3, 2);
            displayVariant1(al);

            al[0] = "good";
            displayVariant1(al);
            //al[100] = "incorrect";

            ArrayList al1 = new ArrayList();
            al1.Add(10);
            al1.Add(20);
            al1.Add(30);
            al1.Add(40);
            al1.Add(50);

            int pos = al1.BinarySearch(20);//1
            pos = al1.BinarySearch(25);//bit's complement of  position 2
            Console.WriteLine("Binary serach of 25"+pos);
            Console.WriteLine(al1.Count);
            pos = al1.BinarySearch(125);//bit's complement of 5(al1.Count)
            Console.WriteLine("Binary serach of 125" + pos);



            // 32 bits
            // 2 -- 000000000000000010
            // 1's complement of 2 -- 111111111111111111101
            // convert this back to decimal -- -3

            //Hashtable
            Hashtable ht = new Hashtable();
           
            ht.Add(102, "tara");
            ht.Add("sara", 101);
            ht.Add(103, "jack");
            ht.Add("Sara", 105);
            ht.Add(104, "puja");
            ht.Add("harry", 106);
            ht.Add(-23, 106);
            ht["harry"] = 999;// correct
            //ht.Add("harry", 777);// add an new element with the same key -- exception

            Hashtable ht2 = new Hashtable() { 
                {"P101","apple" },
                { "P102","mangoes"},
                { "P103","strawberry"}
            };

            Console.WriteLine("hash table 1");
            foreach(DictionaryEntry de in ht)
            {
                Console.WriteLine($"{de.Key}: {de.Value}");
            }
            int v1=(int)ht["harry"];
            Console.WriteLine("The value for the key harry is " + v1);
            //v1=(int)ht["geeta"];// will return null
            if(ht.ContainsKey("jack"))
            {
                v1 = (int)ht["jack"];
                Console.WriteLine("The value for the key jack is " + v1);
            }

            Console.WriteLine("Is apple present in ht2" +ht2.ContainsValue("apple"));

            ht2.Remove("P102");
            ht2.Remove(102);// will not throw an exception; if 102 is not present, it cannot remove it
            foreach (DictionaryEntry de  in ht2)
            {
                Console.WriteLine(de.Key + " : " + de.Value);
            }

            var allKeys = ht2.Keys;// return a object of ICollection
            // store it in any data type which implements ICollection
            string[] arr1 = new string[10];
            ht2.Keys.CopyTo(arr1,0);

            foreach (var item in arr1)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Set of keys");
            IEnumerable<string> allKeys2 = ht2.Keys.Cast<string>();
            foreach (string item in allKeys2)
            {
                Console.WriteLine(item);
            }
            Console.WriteLine("Set of Values");
            ICollection ic1=ht2.Values;// set of all values in the hashtable ht2;
            foreach(var item in ic1)
            {
                Console.WriteLine(item);
            }


            Hashtable emp = new Hashtable()
            {
                {101,new Employee(101,"sara") },
                {102,new Employee(102,"lara") },
                {103,new Employee(103,"tara") },
            };
            ICollection ic2 = emp.Values;// set of all values in the hashtable ht2;
            foreach (var item in ic2)// weakly typed
            {
                Console.WriteLine(item);
            }

            Employee temp = (Employee)emp[101];// reference
            temp.empName = "geeta";
            Console.WriteLine(temp);
            ic2 = emp.Values;// set of all values in the hashtable ht2;
            foreach (Employee item in ic2)
            {
                Console.WriteLine(item);
            }
            IEnumerable<Employee> e1=emp.Values.Cast<Employee>();// strongly typed 
            foreach (Employee item in e1)
            {
                Console.WriteLine(item);
            }
            Console.Read();



        }
    }
}


/*
 * Collections
 * -- dynamic size
 * -- Easy to modify the collection (add or remove)
 * Types:
 * 1. Generic Collections
 * 2. Non generic Collections -- Can hold values which belong to different data type
 *  a. ArrayList; HashTable; Stack,Queue, SortedList,BitArray
 *  Implement Interfaces 
 *  
 *  ArrayList -- Inherit Object
 *  Implements  ICollection, IEnumerable,IList,ICloneable
 *  
 *  
 *  Assignments:
 *  1.Stack -- add elements, remove elements, modifying ; traverse
 *  2.Queue -- add elements, remove elements, modifying ; traverse
 *  
 *  3. Use cases of stack and queue 
 *  4. Limitations about stack,queue, array list
 *  stack memory is very limited --> inbuilt stack 
 *  Stack collection -- memory -- dynamic
 *  
 *  Capacity always is more than count
 *  int[] arr=new int[100];
 *  Storage max-100; min -0
 *  
 *  Stack str=new Stack()
 *  Storage max - 8; min -0;
 *  a. Random access or random modification is not possible
 *  b. Dynamically typed -- disadv 
 *  -- Type security
 *  -- Conversions have to be always done. And since every element is of the object type, the corresponding conversions have to be typed
 *  
 *  stack overflow and stack underflow
 *  stack overflow -- memory is full and there is no place for insertion(push)
 *  stack underflow -- no elements to stack to pop
 *  
 *  
 *   Convert an object to int --Convert.ToInt32()
 *   Convert a object to string -- toString()
 *   Convert a object to boolean value -- Convert.ToBoolean()
 *   
 *  5. Create a int Array list. Write a function to sort the integer arraylist
 *  
 *  
 *  
 */

/*
 * Hashtable -- key, value pairs
 * keys -- unique, cannot ne null
 * values -- can belong to any data type;
 * values can be accessed using myHashTable[key]
 * Compute the hash code of the key  and store internally based on the hash code
 * Array List -- modifiable
 * Stack and queue -- not modifiable
 * hashtable -- modifiable
 */