﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionExamples
{
    class Program
    {
        static void displayVariant1(ArrayList arr)
        {
            foreach (var item in arr)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();
        }
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();
            al.Add(100);
            al.Add(100.56);
            al.Add("hello");
            al.Add(true);
            al.Add(new int[] { 10, 20, 30 });
            displayVariant1(al);

            Console.WriteLine("Count of elements in the array list" + al.Count);
            Console.WriteLine("Capacity of the array list" + al.Capacity);
            Console.WriteLine("Is the array list read only" + al.IsReadOnly);

            // add some elements at a particular position
            al.Insert(2, 999);

            // add a range of values at the end
            ArrayList colours = new ArrayList() { "red","blue","pink"};
            al.AddRange(colours);// will append 

            // add a range of values at a particular position
            ArrayList fruits = new ArrayList() { "apple", "bananas", "mangoes" };
            al.InsertRange(0,fruits);// will append 
            displayVariant1(al);
            Console.WriteLine("Count of elements in the array list" + al.Count);
            Console.WriteLine("Capacity of the array list" + al.Capacity);
            Console.WriteLine("Is the array list read only" + al.IsReadOnly);

            // remove the last element -- pop -- from the end
            al.RemoveAt(al.Count - 1);
            displayVariant1(al);

            // remove on basis of value
            al.Remove("hello");
            displayVariant1(al);

            // remove multiple elements based on the position
            al.RemoveRange(3, 2);
            displayVariant1(al);

            al[0] = "good";
            displayVariant1(al);
            //al[100] = "incorrect";
            Console.Read();


        }
    }
}


/*
 * Collections
 * -- dynamic size
 * -- Easy to modify the collection (add or remove)
 * Types:
 * 1. Generic Collections
 * 2. Non generic Collections -- Can hold values which belong to different data type
 *  a. ArrayList; HashTable; Stack,Queue, SortedList,BitArray
 *  Implement Interfaces 
 *  
 *  ArrayList -- Inherit Object
 *  Implements  ICollection, IEnumerable,IList,ICloneable
 *  
 *  
 *  Assignments:
 *  1.Stack -- add elements, remove elements, modifying ; traverse
 *  2.Queue -- add elements, remove elements, modifying ; traverse
 *  
 *  3. Use cases of stack and queue 
 *  4. Limitations about stack,queue, array list
 *  5. Create a int Array list. Write a function to sort the integer arraylist
 *  
 *  
 *  
 */