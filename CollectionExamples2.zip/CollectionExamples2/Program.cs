﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionExamples2
{
    class Employee
    {
        public int empId;
        public string empName;

        public Employee(int empId, string empName)
        {
            this.empId = empId;
            this.empName = empName;
        }

        public override string ToString()
        {
            return $"EmpId : {empId}; Emp Name : {empName}";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            SortedList sl = new SortedList();// Non generic type
            SortedList<int,string> slGeneric= new SortedList<int, string>();
            //sl.Add(101, "sara");
            //sl.Add("tara", 102);
            slGeneric.Add(101, "sara");
            //slGeneric.Add("tara",102);
            
            
            sl.Add(new Employee(101, "sara"), "sara");
            sl.Add(new Employee(100, "tara"), "tara");
            sl.Add(new Employee(102, "lara"), "lara");
            
            //jagged array in c#

            //sl.GetByIndex();
            //sl.GetKey();
            //sl.GetKeyList();
            //sl.GetValueList();

            // what is the use of abstract keyword in c# with an example 
            //and what is the difference b/w virtual and abstract


        }
    }
}

/*
 * Sorted List 
 * Store the values in the form key-value pairs that are sorted on basis of the key
 * 
 * Can have a version of generic and non generic
 * Key -- unique and not null
 * value -- null and duplicates
 * 
 */
