﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Examples
{
    class Person
    {
        string _name;
        int _age;

        public int Age
        {
            get { return _age; }
            set { if (value > 0)
                {
                    _age = value;
                }
                else
                {
                    throw new Exception("Age cannot be less than or equal to zero");
                }
                }
        }

        public string Name
        {
            get { return _name; }
            set { 
                    if(!string.IsNullOrEmpty(value))
                    {
                        if(value.Length >=2)
                        {
                           _name = value;
                            return;
                        }
                    }
                    throw new Exception("Name fails the validation");
                }
        }

        public Person(int age, string name)
        {
            Age = age;
            Name = name;
        }

        public override string ToString()
        {
            return $"Name : {Name}; Age : {Age}";
        }
        // write the corresponding properties
        // write the constructor
        public virtual void  displayDetails()
        {
            Console.WriteLine($"Name :{ Name}");
            Console.WriteLine($"Age :{ Age}");
        }
    }
}
