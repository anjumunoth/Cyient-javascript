﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Examples
{
    class Product
    {
        int _productId, _quantityAvailable;
        double _price;
        string _productName;
        int _readOnlyField, _writeOnlyField;
        string _productCode;

        public string ProductCode
        {
            get {
                    switch(_productCode)
                    {
                    case "MOB": return "Mobile"; break;
                    case "LAP": return "Laptop"; break;
                    case "DESK": return "Desktop"; break;
                    case "MEMCARD": return "MEMORY card"; break;
                    default: return "Not assigned";

                }
            }
            set { _productCode = value; }
        }

        public int QuantityAvailable
        {
            get { return _quantityAvailable; }
            set
            {
                if (value >= 0)
                {
                    _quantityAvailable = value;
                }
                else
                {
                    Console.WriteLine("Invalid assignment for quantity!! Quantity > =0");
                }

            }

        }
        public string Category { get; set; }// automatic property; property is based on an anonymous private field

        public string SubCategory1 { get; }// automatic read only property
        //public string SubCategory2 { set; }// automatic write only property is not possible

        public int ProductId
        {
            get { return _productId; }
        }
        public int ReadOnlyProperty
        {
            get { return _readOnlyField; }
        }

        public int WriteOnlyProperty
        {
            set { _writeOnlyField = value; }
        }
        public string ProductName// property
        {
            get { return _productName; }
            set { _productName = value.Substring(0,3).ToUpper(); }// value is a keyword
        }

        public double Price
        {
            get { return _price; }
            set
            {
                if (value > 0)
                {
                    _price = value;
                }
                else
                {
                    // raise an exception
                    throw new Exception("Price cannot be less than or equal to zero");
                }
            }

        }
    

    public Product(int productId, int quantityAvailable, double price, string productName)
    {
        _productId = productId;
        _quantityAvailable = quantityAvailable;
        _price = price;
        _productName = productName;
        _readOnlyField = 100;
        _writeOnlyField = 200;
        Category = "mobiles";
    }
    // setter and getter functions -- because the fileds are private and they cannot be accessed outside the class
    public void setProductId(int pId)
    {
        this._productId = pId;
        getProductId();
        Console.WriteLine("fininshed with setproductID");
    }
    public int getProductId()
    {
        return this._productId;
    }
}
class Program
{
        static void compareStudents(Student s1,Student s2)
        {
            if(s1.calcAverage() > s2.calcAverage())
            {
                Console.WriteLine($"{s1.Name} has a better average than {s2.Name}");
            }
            else
            {
                Console.WriteLine($"{s2.Name} has a better average than {s1.Name}");
            }
        }
        static Person comparePerson(Person p1,Person p2)
        {
            if (p1.Age > p2.Age)
            {
                Console.WriteLine($"{p1.Name} is older than {p2.Name}");
                return p1;
            }
            else
            {
                Console.WriteLine($"{p2.Name} is older than {p1.Name}");
                return p2;
            }
        }
    static void Main(string[] args)
    {
        Product p1 = new Product(101, 12, 23.5, "Apple");
        p1.setProductId(777);
        Console.WriteLine("New product Id" + p1.getProductId());
        Console.WriteLine("Old Product name" + p1.ProductName);// getter of the property;"Apple"
        p1.ProductName = "Samsung";// setter of the property;samsung will be stored as "value"
        Console.WriteLine("New Product name " + p1.ProductName);// getter of the property; "SAM"

        Console.WriteLine("Old Product Price " + p1.Price);// getter of the property
        p1.Price = 45.678;// setter of the property;45.678 will be stored as "value"
        Console.WriteLine("New Product Price " + p1.Price);// getter of the property
        try
            {
                p1.Price = -45.678;// setter of the property;
                Console.WriteLine("New Product Price " + p1.Price);// getter of the property

            }
        catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }

        Console.WriteLine("Value in the read only filed" + p1.ReadOnlyProperty);
        //p1.ReadOnlyProperty = 22;
        p1.WriteOnlyProperty = 103;
        //Console.WriteLine("Value in the write only filed" + p1.WriteOnlyProperty);
        p1.QuantityAvailable = -5;
        Console.WriteLine("Quantity " + p1.QuantityAvailable);//-5
        p1.ProductCode = "MOB";// set accessor
        Console.WriteLine("Product Code" + p1.ProductCode);//Mobile 
            p1.ProductCode = "CAM";
            Console.WriteLine("Product Code " + p1.ProductCode);//Not assigned
            Person perObj1 = new Person(25, "Sara");
            Console.WriteLine("Person 1 details" + perObj1);

            try
            {
                Person perObj2 = new Person(-3, "Tara");
                Console.WriteLine("Person 2 details" + perObj2);
                Person perObj3 = new Person(0, "Tara");
                Console.WriteLine("Person 3 details" + perObj3);

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Student stud1 = new Student(23, "tara", new float[] { 10, 20, 30 }, 102);
            stud1.calcAverage(12.3f);//matched overloaded method will be called
            //stud1.calcAverage("hello");//no overloaded method; syntactical error
            Person pObj = new Person(22, "harry");
            Student stud2=new Student(44,"geeta", new float[] { 10, 20, 30 }, 103);
            pObj.displayDetails();//22, "harry"

            stud2.displayDetails();//marks, 103; 44 ; geeta

            Person pObj2=new Student(34, "sita", new float[] { 10, 20, 30 }, 104);// upcasting
            //Student s1 = new Person(22, "jack");
            //Student s1 = (Student)pObj;// downcasting explicitly; exception
            Student s1=(Student)pObj2;// downcasting explicitly but only downcast the object which has been upcasted
            s1.displayDetails();// 34 sita , marks, 104

            Student stud201 = new Student(11, "sara", new float[] { 10, 20, 30 }, 201);
            Student stud202 = new Student(14, "tara", new float[] { 40, 20, 30 }, 202);

            compareStudents(stud201, stud202);

            Person p203= new Student(11, "jack", new float[] { 40, 20, 40 }, 203);
            Person p204= new Student(11, "harry", new float[] { 40, 40, 40 }, 204);

            //compareStudents(p203, p204);// wrong way of doing it
            Person p205 = new Person(12, "janaki");
            Person p206 = new Person(13, "farah");
            
            Person personResult=comparePerson(p205, p206);
            Console.WriteLine("Person Result" + personResult);

            Student studentResult=(Student)comparePerson(stud201, stud202);// upcasting and downcasting
            Console.WriteLine("studentResult" + studentResult);

            // Person -- parent(bigger) data type; Student -- child(smaller) data type
            int i1 = 100;
            double d1 = i1;//implicitly do the conversion smaller data type can be type casted to a bigger data type implicitly; upcasting
            Console.WriteLine(d1);//100
            Console.ReadLine();



    }
}
}


/*
 * Problems with the getter and setter functions
 * 1. More lines of code
 * 2. Problems with function -- 
 * 4 fields -- 8 functions 
 * assign some values to 4 fields -- 4 functions will be called -- 4 times stack will be created and destroyed -- wastage of resources
 * 
 * To overcome these problems we have properties
 * 1. Properties works like fields
 * 2. Declare properties of type public
 * 3. can make it read only or write only depending upon the requirement
 * 4. Validations can be done on the properties as well 
 * 5. Can call inbuilt or custome functions as part of the accessors
 * 6. Can work on the data being set or being returned(for eg switch )
 * 
 * Types of Properties
 * 1. Normal Property
 * 2. Read only property -- Length of the string, Length of the array -- only the get accessor
 * 3. Write only property -- only the set accessor
 * 4. Automatic property or auto implemented properties
 *      -- get accessor is mandatory
 *      -- set accessor is optional
 *      -- based on any anonymous private field
 */

/*
 * Upcasting -- typecast a child object to the parent object ; will happen implicitly
 * Downcasting -- type cast a parent object to the child object; have to do it explicitly
 * -- downcasting explicitly but only downcast the object which has been upcasted
 */


/*
 * class Vehicle{}// parent
 * class Car :Vehicle{}// child
 * 
 * Vehicle v1=new Vehicle();
 * Car c1=new Car();
 * 
 * Vehicle v2=new Car();// correct ; upcasting
 * Car c3=v2;// incorrect
 * Car c3=(Car)v2;// correct ; explicit type casting -- downcasting
 * 
 * 
 */