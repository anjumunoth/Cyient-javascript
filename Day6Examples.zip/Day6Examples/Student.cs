﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day6Examples
{
    class Student:Person
    {
        int _studId;
        public float[] marks;
        public int StudId
        {
            get { return _studId; }
            set { _studId = value; }
        }

        public Student(int age,string name,float[] marks, int studId):base(age,name)
        {
            this.marks = marks;
            StudId = studId;
        }

        public float calcAverage()
        {
            float avg = marks.Average();
            Console.WriteLine($"Average of student with studId {StudId} is {avg}");
            return avg;
        }
        public float calcAverage(float weightage)
        {
            float avg = marks.Average()*weightage;
            Console.WriteLine($"Average of student with studId {StudId} is {avg}");
            return avg;
        }
        public override void displayDetails()
        {
            Console.WriteLine($"StudentId :{ StudId}");
            Console.WriteLine($"Marks:");
            Array.ForEach(marks, (item) =>
             {
                 Console.Write(item+" ");
             });
            Console.WriteLine($"Name :{ Name}");
            Console.WriteLine($"Age :{ Age}");
        }

    }
}


/*
 * Polymorphism
 * types
 * 1. Compile time polymorphism -- Static polymorphism --overloading(method,constructor,operator)
 * Check for the method at the compile time;
 * If the method is not found, it will not allow the excution and throw as a syntactical error
 * 2. Run time polymorphism dynamic polymorphism-- overriding 
 * Check for the method at run time
 * 
 */