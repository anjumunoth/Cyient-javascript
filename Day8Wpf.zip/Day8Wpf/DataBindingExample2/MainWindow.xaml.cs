﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataBindingExample2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        UserRepo userDetails = new UserRepo();
        public MainWindow()
        {
            InitializeComponent();
            this.listUsers.ItemsSource = userDetails.GetAllUsers();
            
            this.listUsers.SelectedIndex = 0;
        }

        private void btnAddNewUser_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("new User button clicked");
            this.wrapPanelAddNewUser.Visibility = Visibility.Visible;
        }

        private void btnEditUser_Click(object sender, RoutedEventArgs e)
        {
            if (this.listUsers.SelectedItem != null)
            {
                MessageBox.Show(this.listUsers.SelectedItem.ToString());

                this.wrapPanelEditUser.Visibility = Visibility.Visible;
            }
            else
                MessageBox.Show("No item selected to edit");
        }

        private void btnSaveAddNewUser_Click(object sender, RoutedEventArgs e)
        {
            if(txtNewFirstName.Text!= null && txtNewLastName.Text !=null)
            {
                this.wrapPanelAddNewUser.Visibility = Visibility.Hidden;
                User newUser = new User(txtNewFirstName.Text, txtNewLastName.Text);
                userDetails.addNewUser(newUser);
            }
            txtNewFirstName.Text = "";
            txtNewLastName.Text = "";
            
        }

        private void btnSaveEditUser_Click(object sender, RoutedEventArgs e)
        {
            User editedUserDetails = new User(txtEditFirstName.Text, txtEditLastName.Text);
            User oldUser = this.listUsers.SelectedItem as User;
            bool result=userDetails.editUser(editedUserDetails,oldUser);
            if(result)
            {
                MessageBox.Show("User details updated successfully");
            }
            else
            {
                MessageBox.Show("User details could not be updated");
            }
            this.wrapPanelEditUser.Visibility = Visibility.Hidden;
            txtEditFirstName.Text = "";
            txtEditLastName.Text = "";
        }
    }
}

/*
 * MVC - Angularjs
 * 
 * MVVM - Model View ViewModel
 * Model -- data of the app
 * View -- UI -- design the view using XAML
 * 
 * ViewModel -- bridge between the view and model ; whenever the view changes, the model should get updated; whenever the model changes, update the view correspondingly
 * 
 * Instead of working with List, Observable Collection is used
 */
