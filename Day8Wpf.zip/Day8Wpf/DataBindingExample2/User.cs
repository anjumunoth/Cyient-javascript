﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBindingExample2
{
    public class User : INotifyPropertyChanged
    {
        string _firstName, _lastName;
        public string FirstName
        {
            get { return this._firstName; }
            set
            {
                this._firstName = value;
                this.NotifyPropertyChanged("FirstName");
            }
        }
        public string LastName
        {
            get { return this._lastName; }
            set
            {
                this._lastName = value;
                this.NotifyPropertyChanged("LastName");
            }
        }

        public void NotifyPropertyChanged(string propName)
        {
            if(this.PropertyChanged !=null)
            {
                // trigger the event
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
            }
        }
        

        public User(string firstName, string lastName)
        {
            FirstName = firstName;
            LastName = lastName;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public override string ToString()
        {
            return $" FirstName : {FirstName}; LastName : {LastName} ";
        }
    }
}
