﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DataBindingExample2
{
    class UserRepo
    {
        ObservableCollection<User> usersArr = new ObservableCollection<User>();
        public UserRepo()
        {
            usersArr.Add(new User("asha", "mehta"));
            usersArr.Add(new User("meera", "shah"));
            usersArr.Add(new User("seeta", "khan"));
            usersArr.Add(new User("sara", "mehta"));
        }

        public ObservableCollection<User> GetAllUsers()
        {
            return this.usersArr;
        }

        public bool addNewUser(User newUser)
        {
            MessageBox.Show("New user added" + newUser.ToString());
            usersArr.Add(newUser);
            return true;
        }
        public bool editUser(User editedUser,User oldUser)
        {
            for(int i=0;i<usersArr.Count;i++)
            {
                if(this.usersArr[i].FirstName == oldUser.FirstName && this.usersArr[i].LastName== oldUser.LastName)
                {
                    usersArr[i] = editedUser;
                    return true;
                    
                }
            }
            return false;
        }
    }
}
