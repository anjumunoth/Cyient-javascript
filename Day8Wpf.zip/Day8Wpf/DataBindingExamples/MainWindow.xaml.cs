﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataBindingExamples
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public User MyUser { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;

            Binding binding = new Binding("Text");
            binding.Source = txtLastName;
            lblUserLastName.SetBinding(TextBlock.TextProperty, binding);

            this.MyUser = new User("asha", "mehta");

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            BindingExpression binding = txtWidth.GetBindingExpression(TextBox.TextProperty);
            binding.UpdateSource();// explicitly change the binding
        }
    }
}

/*
 * Binding:
 * 1. Binding one control on basis of another control
 * 2. Binding with the resources
 * 3. Template binding
 * 4. Data binding
 * a. One way data binding
 * b. two way data binding
 * 
 * Data Binding 
 * 1. Set up data context
 * 2. Two way data binding
 * 
 */