﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace DispatcherExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            DispatcherTimer timer = new DispatcherTimer();// window.setInterval()
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += myFunc;
            timer.Tick += Timer_Tick;
            timer.Start();
            
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            if(DateTime.Now.Minute %2 ==0)
            {
                lblClock.Background = new SolidColorBrush(Colors.Aquamarine);
                    
            }
            else
                lblClock.Background = new SolidColorBrush(Colors.Plum);
        }

        void myFunc(object sender,EventArgs e)
        {
            lblClock.Content = DateTime.Now.Minute + "m" + DateTime.Now.Second + "s";
        }
    }
}

/*
 * setInterval(myFunc,1000);
 * 
 */
