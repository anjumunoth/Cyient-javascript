﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesExample
{
    class Example
    {
        public int CalculateSum(int op1, int op2)
        {
            return op1 + op2;
        }
        public int CalculateSquare(int op1)
        {
            return op1 * op1;
        }
        public int CalculateSquare1(string op1,string op2)
        {
            return op1.Length * op2.Length;
        }
        public string CalculateSquare2(int op1, int op2)
        {
            return (op1 + op2).ToString();
        }
        public static int staticCalculateSum(int op1, int op2)
        {
            return op1* op2;
        }

    }
    class Program
    {
        // declare a delegate
        public delegate int myMethodDelegate(int p1, int p2);

        static void Main(string[] args)
        {
            int a = 10;// adding some constraints to the variable
            //a = 10.5;
            Example e1 = new Example();
            myMethodDelegate d1 = new myMethodDelegate(e1.CalculateSum);

            // invoke the delegate
            int res=d1(10, 20);
            Console.WriteLine("Result = "+res);

            //myMethodDelegate d2 = new myMethodDelegate(e1.CalculateSquare);
            //myMethodDelegate d2 = new myMethodDelegate(e1.CalculateSquare1);
            //myMethodDelegate d2 = new myMethodDelegate(e1.CalculateSquare2);
            myMethodDelegate d2 = new myMethodDelegate(Example.staticCalculateSum);
            res = d2(10, 20);
            Console.WriteLine("Result of static function called using the delegate = " + res);//200
            d2 = new myMethodDelegate(e1.CalculateSum);
            res = d2(10, 20);
            Console.WriteLine("Result of static function called using the delegate = " + res);//30

            List<int> l1 = new List<int>() { 10, 20, 30, 40, 50 };
            int answer=l1.Find((item) => {
                return (item > 20);//return a boolean
            });
            //answer = l1.Find((item) => {
            //    return (item + 20);// return a integer
            //});

            
            Console.WriteLine(answer);//30
            Console.ReadLine();
        }
    }
}
/*
 * int a=10,b=2345678909876543234567890;
 * Constraints when declaring a variable as integer;
 * -- Should have whole numbers
 * -- Range of values it can take
 * 
 * Why are constraints important ?
 * -- Validations
 * -- Proper usage 
 * -- Organised / modularity
 * 
 * Can i put a constraint on a function/method -- yes 
 * 
 * Constraint on a function -- delegate
 * a. On what all the constraints be laid down
 * Constraint on param signature(data type, number and order of params)
 * Constraint on return data type
 * Constraint on access modifiers
 * 
 * Delegate can be casted on an instance method or sstatic method
 * 
 * Delegate -- reference to a function
 * The reference can be changed at run time
 * 
 * delegate keyword for declaring a delegate
 * Create the instance of the delegate and pass the function to which it has to point to as a parameter;
 * 
 * Data and methods which work on the data
 * Different types of delegates --
 * Predicate delegate
 * Action delegate
 * 
 */