﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsExamples
{
    // Publisher class -- create the event;trigger the event;what are the conditions which the event handler has to follow 
    class AddTwoNumbers
    {
        public int Num1 { get; set; }
        // declare a custom delegate which takes in no parameters and returns void
        public delegate void dgOddNumber();
        public event dgOddNumber evOddNumber;

        public delegate void dgCheckPrime(int n1);
        public event dgCheckPrime evCheckPrime;
        // Declaring an event -- name of the event -- evOddNumber;
        // For this event evOddNumber , the corresponding event handler should follow  dgOddNumber delegate constraints

        public void readValues()
        {
            int num1;
            Console.WriteLine("Enter a number");
            bool res = int.TryParse(Console.ReadLine(), out num1);
            if (res)
            {
                Num1 = num1;
            }
            else
                Num1 = 0;
            evCheckPrime(Num1);// raising the event with some data 
            if(!(Num1 %2 ==0))
            {
                // trigger the event
                evOddNumber();// raise the event
            }

        }


    }

    class Subscriber2
    {
        public void Sub2EventHandler()
        {
            Console.WriteLine("The entered number is a odd number from Subscriber 2");

        }
    }
    // Subscriber -- handle the event; event handler shpuld be according to the delegate declared as part of the event
    class Program
    {
        static void OddEventHandler()
        {
            Console.WriteLine("The entered number is not an even number");
        }
        static void PrimeEventHandler(int p1)
        {
            bool flag = false;
            for(int i=2;i<p1/2;i++)
            {
                if(p1%i ==0)
                {
                    flag = true;
                    break;
                }

            }
            if (flag == true)
                Console.WriteLine(p1 + " is Not a prime number");
            else
                Console.WriteLine(p1 + " is a prime number");
            
        }
        static void Main(string[] args)
        {
            AddTwoNumbers a1 = new AddTwoNumbers();
            // link the event with the event handler
            // binding the event handler to the event
            a1.evOddNumber += new AddTwoNumbers.dgOddNumber(OddEventHandler);
            // declare the second subscriber
            Subscriber2 s2 = new Subscriber2();
            a1.evOddNumber += new AddTwoNumbers.dgOddNumber(s2.Sub2EventHandler);

            a1.evCheckPrime += new AddTwoNumbers.dgCheckPrime(PrimeEventHandler);

            a1.readValues();// if the user enters a odd number, the odd event will be triggered and will trigger the prime number events for all numbers

            Console.Read();


        }
    }
}

/*
 * Publisher -- Samsung
 * Samsung will create an event -- fold3 is up for sale;
 * Subscriber(s) -- Poonam, Priyanka, Jyoti
 * subscribers will wait for the event; subscribe for the event(mobile launch)
 * When the event occurs(mobile gets launched), Samsung will notify all the subscribers
 * 
 * The subscribers will take their respective decisions(will handle the event in their own ways)
 * 
 * publisher -- subscriber model 
 * 
 *
 *Event in html and js
 *<input type="button" value="Login" onclick="clickEventHandler();" />
 *In .js
 *function clickEventHandler()
 *{
 *}
 *
 *Event -- onclick
 *Event handler -- clickEventHandler
 *Who is triggering the event -- user -- by clicking on the button
 *
 *Server side :
 *Events :
 *custom events; their corresponding event handlers;
 *trigger the events
 *
 * Combine 3 concepts : Concept of events in html, publisher - subscriber model and delegate topic  ==> events in c#
 * event handler -- always a function -- should adhere to the delegate 
 * publisher will trigger the event; and subscriber will handle the event(write the event handler)
 * 
 * */
