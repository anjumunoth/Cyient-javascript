var empApp=angular.module("empApp",[]);
