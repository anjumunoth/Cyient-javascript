empApp.controller("empAddController",function($scope){
    $scope.newEmployee={};
    $scope.errorMessage="";
    $scope.saveDetailsEventHandler=function(){
        if($scope.addEmpForm.$valid)
        {
            if(parseFloat($scope.newEmployee.salary) <= 1000)
            {
                $scope.errorMessage="Salary must be greater than 0";
                return false;
            }
        }
        console.log("New Employee details entered",$scope.newEmployee);
        // send it to the parent controller
        // emit a custom event from the child controller to its parent(s)
        // emit -- takes 2 params; name of the custom events; optional data to be passed to the parent
        $scope.$emit("addNewEmployee",$scope.newEmployee);

    }
    $scope.cancelAddEmpEventHandler=function(){
        $scope.$emit("cancelAddNewEmployee");
        $scope.newEmployee={};
    }
})