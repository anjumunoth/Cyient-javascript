empApp.controller("empDisplayController",function($scope){
    $scope.companyName="Cyient";
    $scope.empArr=[
    {empId:101,empName:"Asha",salary:1001,deptId:"D1"},
    {empId:102,empName:"Gaurav",salary:2000,deptId:"D1"},
    {empId:103,empName:"Karan",salary:2000,deptId:"D2"},
    {empId:104,empName:"Kishan",salary:3000,deptId:"D1"},
    {empId:105,empName:"Keshav",salary:3500,deptId:"D2"},
    {empId:106,empName:"Pran",salary:4000,deptId:"D3"},
    {empId:107,empName:"Saurav",salary:3800,deptId:"D3"}];
    $scope.selectedEmployee={};
    $scope.showEditEmployee=false;
    $scope.showAddEmployee=false;
    $scope.editEmployeeDetailsEventHandler=function(obj){
        $scope.selectedEmployee=obj;
        alert("U have selected empId :"+ obj.empId + " to edit");
        $scope.showEditEmployee=true;
    }

    $scope.showAddNewEmployeeEventHandler=function()
    {
        $scope.showAddEmployee=true;
    }
    // on method is used to bind an event with an event handler
    // whenever the event gets triggered, the corresponding event handler will be executed
    $scope.$on("addNewEmployee",function(event,newEmployee){
        console.log(newEmployee);
        $scope.empArr.push(newEmployee);
        $scope.showAddEmployee=false;
    })
    $scope.$on("cancelAddNewEmployee",function(){
        $scope.showAddEmployee=false;
    })
})