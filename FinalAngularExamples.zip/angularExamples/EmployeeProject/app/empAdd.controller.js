myApp.controller("empAddController",function($scope,empManage){
    $scope.saveDetailsEventHandler=function(){
        empManage.addEmployee($scope.newEmployee)
    }
})