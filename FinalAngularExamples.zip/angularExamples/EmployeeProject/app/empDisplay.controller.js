myApp.controller("empDisplayController",function($scope,empManage,$interval){
    $scope.empArr=empManage.getAllEmpDetails();
    $scope.showAddEmployee=false;
    $scope.currentDateWithTime=new Date();
    $interval(()=>{
        $scope.currentDateWithTime=new Date();
    },1000)
    $scope.showAddNewEmployeeEventHandler=function(){
        $scope.showAddEmployee=true;
    }
})