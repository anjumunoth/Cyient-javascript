myApp.service("empManage",function(){
    this.empDetails=[
        { empId: 101, empName: "Asha", salary: 1001, deptId: "D1", gender: "F" },
        { empId: 102, empName: "Gaurav", salary: 2000, deptId: "D1", gender: "M" },
        { empId: 103, empName: "Karan", salary: 2000, deptId: "D2", gender: "M" },
        { empId: 104, empName: "Kishan", salary: 3000, deptId: "D1", gender: "M" },
        { empId: 105, empName: "Keshav", salary: 3500, deptId: "D2", gender: "M" },
        { empId: 106, empName: "Pran", salary: 4000, deptId: "D3", gender: "M" },
        { empId: 107, empName: "Saurav", salary: 3800, deptId: "D3", gender: "M" }];

    this.getAllEmpDetails=function()
    {
        return this.empDetails;
    }
    this.addEmployee=function(emp)
    {
        this.empDetails.push(emp);
    }
    this.deleteEmp=function(emp){
        var pos=this.empDetails.findIndex(item=> {
            if(item.empId == emp.empId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.empDetails.splice(pos,1);
    }

})