myApp.controller("empSearchController",function($scope,empManage){
    $scope.empSearchArr=empManage.getAllEmpDetails();
    $scope.deleteEmpEventHandler=function(empToBeDeleted)
    {
        empManage.deleteEmp(empToBeDeleted);
        
    }
})