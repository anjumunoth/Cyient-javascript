myApp.controller("httpFetchDataController",function($scope,$http){
    var serverUrl="https://jsonplaceholder.typicode.com/po";
    $scope.postArr=[];
    $scope.errorMessage="";
    $http.get(serverUrl)    
    .then(response=>{
        console.log(response);
        $scope.postArr=response.data;

    })
    .catch(err=>{
        console.log(err);
        $scope.errorMessage=err;
    })
})