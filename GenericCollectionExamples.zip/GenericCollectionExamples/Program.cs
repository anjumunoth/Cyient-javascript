﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCollectionExamples
{
    class Employee
    {
        public int empId;
        public string empName;

        public Employee(int empId, string empName)
        {
            this.empId = empId;
            this.empName = empName;
        }

        public override string ToString()
        {
            return $"EmpId : {empId}; Emp Name : {empName}";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> numbers = new Stack<int>();
            numbers.Push(100);
            //numbers.Push("hello");

            List<int> marks = new List<int>();
            marks.Add(100);
            marks.Add(200);
            marks.Add(150);
            marks.Add(170);
            marks.Add(200);
            for (int i = 0; i < marks.Count; i++)
            {
                Console.WriteLine(marks[i]);
            }
            Console.WriteLine("Inside the foreach method");
            marks.ForEach(num => { 
                // num is a copy of the element
                num *= 2;
                Console.WriteLine(num); });
            Console.WriteLine("List after changes");
            marks.ForEach(num => { Console.WriteLine(num); });
            // Linq synatx

            // Find

            int element=marks.Find(item => item == 200);
            Console.WriteLine("Find method result" + element);

            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee(101, "sara"));
            empList.Add(new Employee(102, "tara"));
            empList.Add(new Employee(107, "tara"));
            empList.Add(new Employee(103, "lara"));
            empList.Add(new Employee(104, "asha"));
            empList.Add(new Employee(105, "tara"));

            Employee result1=empList.Find(item => item.empName == "tara");
            Console.WriteLine("Emp details with empName : Tara" + result1);//102,tara

            result1 = empList.FindLast(item => item.empName == "tara");
            Console.WriteLine("Emp details with empName : Tara" + result1);//105,tara

            List<Employee> resultList1 = empList.FindAll(item => item.empName == "tara");
            Console.WriteLine("Emp details with empName : Tara" );//102,tara;105,tara
            resultList1.ForEach(item => Console.WriteLine(item));


            result1 = empList.Find(item => item.empName == "Geeta");
            Console.WriteLine("Emp details with empName : Geeta" );//null
            if (result1 == null)
            {
                Console.WriteLine("null");
            }
            else
            {
                Console.WriteLine(result1);
            }
            result1 = empList.FindLast(item => item.empName == "Geeta");
            Console.WriteLine("Emp details with empName : Geeta" );//
            if(result1== null)
            {
                Console.WriteLine("null");
            }
            else
            {
                Console.WriteLine(result1);
            }

            resultList1 = empList.FindAll(item => item.empName == "Geeta");
            Console.WriteLine("Emp details with empName : Geeta");//Empty list
            resultList1.ForEach(item => Console.WriteLine(item));


            int pos=empList.FindIndex(item => item.empName == "tara");
            Console.WriteLine("Index position of tara" + pos);
            pos=empList.FindLastIndex(item => item.empName == "tara");
            Console.WriteLine("Last Index position of tara" + pos);


            bool isExists107=empList.Exists(item => item.empId == 107);

            Console.WriteLine("Count of the List" + empList.Count);
            Console.WriteLine("Capacity of the List" + empList.Capacity);
            empList.TrimExcess();
            Console.WriteLine("Count of the List" + empList.Count);//6
            Console.WriteLine("Capacity of the List" + empList.Capacity);//6

            empList.Add(new Employee(106, "larry"));
            Console.WriteLine("Count of the List" + empList.Count);//7
            Console.WriteLine("Capacity of the List" + empList.Capacity);//8

            empList.Add(new Employee(107, "larry"));
            Console.WriteLine("Count of the List" + empList.Count);//8
            Console.WriteLine("Capacity of the List" + empList.Capacity);//12
            empList.TrimExcess();
            Console.WriteLine("Count of the List" + empList.Count);//8
            Console.WriteLine("Capacity of the List" + empList.Capacity);//8

            empList.Add(new Employee(108, "larry"));
            Console.WriteLine("Count of the List" + empList.Count);//9
            Console.WriteLine("Capacity of the List" + empList.Capacity);//16

            Dictionary<int, string> d1 = new Dictionary<int, string>();
            d1.Add(101, "sara");
            d1.Add(102, "tara");
            d1.Add(103, "lara");
            d1.Add(104, "priya");

            foreach(KeyValuePair<int,string> item in d1)
            {
                Console.WriteLine(item.Key+" : "+ item.Value);
            }

            Console.WriteLine(d1[103]);//"lara"
            d1[103] = "keshav";
            Console.WriteLine(d1[103]);//"lara"
            
            for(int i=0;i<d1.Count;i++)
            {
                Console.WriteLine(d1.ElementAt(i).Key + " : " + d1.ElementAt(i).Value);
            }

            if (d1.ContainsKey(999))
            {
                Console.WriteLine(d1[999]);// keyFoundNotFoundException
            }

            KeyValuePair<int, string> s1 = new KeyValuePair<int, string>(101, "sara");
            bool r1=d1.Contains(s1);
            Console.WriteLine("Is 101 and sara present"+r1);

            s1 = new KeyValuePair<int, string>(101, "tara");
            r1 = d1.Contains(s1);
            Console.WriteLine("Is 101 and tara present" + r1);//false

            // HashSet
            HashSet<string> countryNames = new HashSet<string>();
            HashSet<string> countryNamesInAsia = new HashSet<string>();

            countryNames.Add("Australia");
            countryNames.Add("India");
            countryNames.Add("SriLanka");
            countryNames.Add("Australia");


            Console.WriteLine(countryNames.ElementAt(0));//Australia
            Console.WriteLine("Size of the hashset" + countryNames.Count);
            countryNamesInAsia.Add("India");
            countryNamesInAsia.Add("SriLanka");

            IEnumerable countriesOutsideAsia=countryNames.Except(countryNamesInAsia);// Australia
            Console.WriteLine("Countries outside Asia");
            foreach(var item in countriesOutsideAsia)
            {
                Console.WriteLine(item);
            }

            //countryNames.Intersect(countryNamesInAsia);
            countryNames.ExceptWith(countryNamesInAsia);
            Console.WriteLine("Elements in country names after except with");
            foreach(string item in countryNames)
            {
                Console.WriteLine(item);
            }
            
            Console.ReadKey();

           




            //Traversal
            //for loop
            // foreach

        }
    }
}

/*
 * Generic collections
 * -- same data type, dynamic size
 * -- namespace -- System.Collections.Generic
 * -- Type casting to different types -- its not important
 * 
 * List, Dictionary, Stack,Queue, SortedList, HashSet
 * 
 * List -- collection of strongly typed objects
 * -- Access the list using the subscript
 * -- Methods -- modifying, sorting,searching
 * -- very similar to ArrayList
 * -- List is faster than arraylist and less error prone
 * -- Add, AddRange
 * -- Insert(index,value)
 * -- Remove(element), RemoveAt(index), RemoveRange
 * -- bool Contains(element)
 * -- int BinarySearch(element)-- position of the element in the given List
 * -- CopyTo -- copy the elements in the List Collection to a one-dimensional array
 * -- Clear
 * -- Sort
 * 
 * --Exists
 * -- ForEach
 * -- TrimToSize
 * -- Find
 * 
 * 
 * Dictionary 
 * -- Equivalent to hash table in non generic collection
 * -- key- value pairs
 * 
 * 
 * HashSet
 * -- values are going to stored according to the hash values
 * -- Set -- no duplicates
 * 
 * Assignments
 * // Find all index of all the occurences in a List
 * An example for intersectWith, unionWith
 * Can a function in c# return multiple values. If yes how??
 * 
 * static public void method1(int a)
 * {
 *      a++;
 * }
 * 
 * Main()
 * {
 *      int p1=100;
 *      method1(p1);
 *      Console.WriteLine(p1);//101; Dont change the return type; dont change the code in Main
 * }
 */
