﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InBuiltDelegatesExample
{
    class Program
    {
        static void CheckEvenOrOdd(int p1)
        {
            if (p1 % 2 == 0)
                Console.WriteLine($"{p1} is an even number ");
            else
                Console.WriteLine($"{p1} is an odd number ");
        }
        static int SumOfTwoNumbers(int x, int y)
        {
            return x + y;
        }
        static void Main(string[] args)
        {
            Func<int, int, int> add = SumOfTwoNumbers;
            int res = add(10, 20);
            Console.WriteLine("Result of adding 2 numbers" + res);

            // pointing to an anonymous function
            Func<string, string> convertToUpper = (p1) =>
              {
                  return p1.ToUpper();
              };
            string UpperCaseStr=convertToUpper("hello");
            Console.WriteLine("String in Uppercase" + UpperCaseStr);

            // No input but return a single output

            Func<bool> checkForEquality = () => {
                int r1 = new Random().Next(1, 10);
                int r2 = new Random().Next(1, 10);
                Console.WriteLine($"R1 : {r1}; R2 : {r2}");
                return r1 == r2;
            };
            bool re1=checkForEquality();
            Console.WriteLine("Are 2 numbers equal" + re1);

            Func<string, string, string, string> replaceStrings = (s1, s2, s3) =>
            {
                bool contain = s1.Contains(s2);
                if (contain)
                {
                    //strings are immutable 
                    s1 = s1.Replace(s2, s3);
                }
                return s1;
            };
            string result = replaceStrings("apple", "a", "e");
            Console.WriteLine("replace the s1 in place s2 with s3" + result);


            //Declare a function delegate which takes in 3 paramters of string type -- replace operation and return the new string

            // Declare a function delegate which takes in an array of object of product type, and integer and returns the products which has the corresponding productId

            Action<int> MyActionDel = CheckEvenOrOdd;
            MyActionDel(10);

            // Create a action delegate which will calculate the sum of all the product prices;


            // Delegate pointing to an anonymous method
            Action<int> myActionDel2 = delegate (int p1)
             {
                 if (p1 % 2 == 0)
                     Console.WriteLine($"{p1} is an even number ");
                 else
                     Console.WriteLine($"{p1} is an odd number ");
             };
            myActionDel2(9);

            List<int> arrList = new List<int>() { 10, 20, 30 };
            
            Predicate<string> checkForUpper = delegate (string s1)
            {
                if (s1.Equals(s1.ToUpper()))
                    return true;
                else
                    return false;
            };
            bool re2=checkForUpper("Hello");
            Console.WriteLine("Is Hello in Upper" + re2);


            //Predicate<Products> predDel1=delegate(Products s1)
            //{
            //    if (s1.productId == "100a")
            //    {
            //        return true;
            //    }
            //    else
            //        return false;
            //}
            //proArr.Find(predDel1);


            Console.ReadLine();
        }
    }
}


/*
 * Ways of making a delegate point to a function
 * 1. MyDelegate myDelegateObj=new MyDelegate(func1);
 * 2. MyDelegate myDelegateObj=func1;
 * 3. MyDelegate myDelegateObj=()=>{};// lambda function
 * 4. MyDelegate myDelegateObj= delegate (paramlist){body of the function}
 * 
 * 
 * In built Delagate: System namespace
 * Function delegate : 
 * Used with the Func Delegate
 * Generic delagate
 * The last param is always the return data type
 * Func Delegate can take in 0 to 16 input parameters but return a single value(last parameter)
 * Does not allow ref and out parameters
 * 
 * Eg:Take 2 int params and return an int value
 * 
 * 
 * 
 * Action Delegate
 *  -- Inbuilt delegate
 *  -- Similar to Func Delegate except that action delegates dont return a value
 *  --can take in 0 to 16 input parameters but returns void
 *  
 *  Predicate Delegate
 *  -- Inbuilt Delegate
 *  -- Similar to Func Delegate except that Predicate Delegate -- only one input and always only return a bool value
 *  -- In the List class, Find 
 *  
 *  
 */

/*
 * Assignment 
 * 1. What is boxing and unboxing in C#? 
 * 2. 
 */