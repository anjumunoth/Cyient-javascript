﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExamples
{
    class Father
    {
        public int salary;

        public Father(int salary)
        {
            this.salary = salary;
        }
        public void display()
        {
            Console.WriteLine(salary);
        }
    }
    class Mother
    {
        public string favoriteDish;

        public Mother(string favoriteDish)
        {
            this.favoriteDish = favoriteDish;
        }
        public void display()
        {
            Console.WriteLine(favoriteDish);
        }
    }

    //class Child : Father, Mother
    //{
    //    public string schoolName;
    //    public Child(string sName,string fDish, int salary):base()// first point of ambiguity
    //    {        }
    //}

    interface I3
    {
        int P1 { get; }
        int P2 { set; }
        int P3 { get; set; }
    }
    interface I1
    {
       void ChangeSpeed(int p1);//by default public abstract method
        bool stopVehicle();
        
    }
    interface I2
    {
        void stopVehicle();
        void startVehicle();
        void ChangeSpeed(string p1);
        int MaxSpeed { get; set; }
        
    }

    class Vehicle:I1,I2//inheriting from Object
    {
        int vehicleId;
        int _maxSpeed;
        public int Speed { get; set; }
        public int MaxSpeed { get {return _maxSpeed; } set {_maxSpeed=value; } }
        public Vehicle(int vehicleId, int speed)
        {
            this.vehicleId = vehicleId;
            Speed = speed;
        }
        public void ChangeSpeed(int p1)// implementing the interface methods
        {
            Speed = p1;
        }
        public void ChangeSpeed(string p1)
        {
            Speed = p1.Length * 10;
        }
        public void stopVehicle()
        {
            Speed = 0;
        }
        public void startVehicle()
        {
            Speed = 10;
        }
        bool I1.stopVehicle()
        {
            Speed = -1;
            return false;
        }
        public override string ToString()
        {
            return $"VehicleId : {vehicleId}; Speed: {Speed}";
        }
    }
    class Program
    {
        static void referenceMethod(int a,ref int b)
        {
            a++;
            b++;
        }

        static void methodWithOutParam(int a ,out int b)
        {
            //Console.WriteLine("The value in the out parameter" + b);//1000
            b = 100;
        }


        static void addAndMultiplyTwoNumbers(int a, int b, out int addRes,out int mulRes)
        {
            addRes = a + b;
            mulRes = a * b;
        }

        static void stringModify(ref string str)
        {
            str = str.ToLower();
        }

        static void arrayModify(int[] arr)
        {
            for(int i=0;i<arr.Length;i++)
            {
                arr[i] *= 2;
            }
        }

        static void listModify(List<int> arr)
        {
            for (int i = 0; i < arr.Count; i++)
            {
                arr[i] *= 2;
            }
        }
        static void Main(string[] args)
        {
            int p1 = 100, p2 = 200;
            referenceMethod(p1,ref p2);
            Console.WriteLine($"P1: {p1}");//100
            Console.WriteLine($"P2: {p2}");//201

            //referenceMethod(100, ref 200);
            //const double PI= 3.14;
            //referenceMethod(100, ref PI);
            int p3=1000;
            referenceMethod(100, ref p3);

            methodWithOutParam(100, out p3);
            Console.WriteLine("Output of the out varaible" + p3);//100

            int add1, mul1;
            addAndMultiplyTwoNumbers(100, 200, out add1, out mul1);
            Console.WriteLine("Output of Addition " + add1);
            Console.WriteLine("Output of Multiplication " + mul1);
            //int res;
            //bool r=Int32.TryParse(Console.ReadLine(),out res);
            string str = "CYIENT";
            stringModify(ref str);
            Console.WriteLine("CompanyName : " + str);//CYIENT

            int[] numbers = new int[] { 10, 20, 30 };
            arrayModify(numbers);
            foreach (var item in numbers)
            {
                Console.Write(item + " ");
            }
            Console.WriteLine();//[10,20,30]

            List<int> l1 = new List<int>() { 10, 20, 30 };
            listModify(l1);
            foreach (var item in l1)
            {
                Console.Write(item + " ");
            }

            //Child obj = new Child();
            //obj.display();// second place of ambiguity

            Vehicle v1 = new Vehicle(101, 70);
            v1.ChangeSpeed(100);
            Console.WriteLine(v1);
            v1.stopVehicle();// method returning void
            Console.WriteLine(v1);
            v1.ChangeSpeed("hi");
            Console.WriteLine(v1);
            // call stopVehicle which returns a boolean value;
            I1 obj = v1;// upcasting
            bool res = obj.stopVehicle();// v1.stopVehicle which returns a bool value
            Console.WriteLine(v1);
            Console.ReadKey();
        }
    }
}


/*
 * Pass by reference:
 * 1. In the function def and function call --> add the ref keyword
 * 2. A ref value in the function call should always be a assignable variable;
 * 3. The referenced parameter need not be modified.
 * 4. The reference variable in the function call should always be initialised
 * * 5. Flow of data -- Both the directions
 * 
 * 
 * Out Parameter:
 * 1. In the function def and function call --> add the out keyword
 * 2. The out parameter in the function should be modified in the implementation otherwise it will throw a syntactical error
 * 3. A out value in the function call should always be a assignable variable;initialisation is not mandatory
 * 4.Before modyfying the out parameter, the value is unassigned; Values from the function call are not copied into the out parameters
 * 5. Flow of data -- from the function to the place where its called
 * Built in function : OrderBy(); 
 * TryParse()
 * 
 * Primitive data types/ Value data types : number, string -- passed by value
 * Array , Object -- passed by reference
 * 
 * 
 * Abstract Class
 * 1. can have concrete methods and abstract methods
 * 2. Can have constructors(all), fields, properties and static fields
 * 3. The child class should override the abstract methods
 * 4. Cannot create objects of the abstract class
 * 
 * Inheritance :
 * 1. Single
 * 2. Multi level inheritance
 * 3. Hierarchial inheritance 
 * Vehicle -- base class
 * Cars -- Inherit from Vehicle
 * Trucks -- Inherit from Vehicle
 * 4. Multiple inheritance
 * Child is inheriting from mother and father
 * In .Net multi inheritance is not allowed
 * 
 * Mandatory -- Child can inherit from only one parent
 * 
 * Interface:
 * 1. methods -- public abstract
 * 2. properties -- public abstract
 * 2. multiple methods
 * 3. constructor, fields -- no
 * , static methods, concrete methods -- no
 * 4. Cannot create an instance
 */