﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SortingExamples
{
    class Employee: IComparable<Employee>
    {
        public int empId;
        public string empName;
        public double salary;

        public int CompareTo(Employee obj)
        {
            if(obj == null)
            {
                return 1;
            }
            if (this == null)
                return -1;
            if (this.salary > obj.salary)
                return 1;
            else
                if (this.salary < obj.salary)
            {
                return -1;
            }
            else
                return 0;
        }
        public Employee(int empId, string empName,double salary)
        {
            this.empId = empId;
            this.empName = empName;
            this.salary = salary;
        }

        public override string ToString()
        {
            return $"EmpId : {empId}; Emp Name : {empName}; Salary:{salary}";
        }
    }

    class EmployeeComparer: IComparer<Employee>
    {
        public int Compare(Employee e1,Employee e2)
        {
            if(e1.empName == e2.empName)
            {
                return 0;
            }
            if (e1.empName.CompareTo(e2.empName) >0)
            {
                return 1;

            }
            else
                return -1;
        }
    }
    class EmployeeIDComparer : IComparer<Employee>
    {
        public int Compare(Employee e1, Employee e2)
        {
            if (e1.empId == e2.empId)
            {
                return 0;
            }
            if (e1.empId.CompareTo(e2.empId) > 0)
            {
                return 1;

            }
            else
                return -1;
        }
    }
    class Program
    {
        static void displayArr(List<Employee> arr)
        {
            foreach(Employee item in arr)
            {
                Console.WriteLine(item);
            }
        }
        static void Main(string[] args)
        {
            List<Employee> empArr = new List<Employee>{
                new Employee(101, "sara", 567),
                new Employee(102, "tara", 4567),
                new Employee(103, "lara", 5673),
                new Employee(104, "asha", 5267),
                new Employee(105, "piyush", 2567)

            };
            empArr.Sort();
            displayArr(empArr);

            Employee[] empArr1 = new Employee[]{
                new Employee(101, "sara", 567),
                new Employee(102, "tara", 4567),
                new Employee(103, "lara", 5673),
                new Employee(104, "asha", 5267),
                new Employee(105, "piyush", 2567)

            };
            Array.Sort(empArr1, new EmployeeComparer());
            Console.WriteLine("According to emp Names");
            foreach(var item in empArr1)
            {
                Console.WriteLine(item);
            }

            Array.Sort(empArr1);// according to IComparable CompareTo
            Console.WriteLine("According to salary");
            foreach (var item in empArr1)
            {
                Console.WriteLine(item);
            }

            Array.Sort(empArr1,new EmployeeIDComparer());
            Console.WriteLine("According to employee Id");
            foreach (var item in empArr1)
            {
                Console.WriteLine(item);
            }
            Console.Read();
        }
    }
}


/*
 * IComparable 
 * -- Always implemented on the original class itself
 * -- Implement CompareTo Method
 * -- This becomes the default way of comparison
 * -- No need to create an instance of IComparable
 * -- Multiple child classes not allowed
 * 
 * 
 * IComparer
 * -- Implement it on a different class other than Employee
 * -- Implement the Compare method
 * -- When doing the sorting, have to explicitly create an object of the class which implements the IComparer and pass as the second argument
 * -- Can have multiple classes which implements the IComparer
 */
