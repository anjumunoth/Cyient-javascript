﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MenuControlExamples
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        bool res;
        public MainWindow()
        {
            InitializeComponent();
            res = false;
        }

        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = res;                
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            txtEditor.Text = "";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int sum1=Int32.Parse(num2.Text) + Int32.Parse(num1.Text);
            if (sum1 > 0)
            {
                res = true;
            }
            else
                res = false;
        }

        private void cmdCut_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void cmdCut_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("Cut command triggered");
            txtEditor.Cut();
        }

        private void cmdCopy_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void cmdCopy_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("Copy command triggered");
            txtEditor.Copy();
        }

        private void cmdPaste_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

        private void cmdPaste_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            MessageBox.Show("Paste command triggered");
            txtEditor.Paste();
            
        }
    }
    
}
