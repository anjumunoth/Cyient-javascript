﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ResourcesExamples
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txtAboutCompany.Text = Application.Current.FindResource("strCompanyName") +" --- "+this.FindResource("keyAboutCyient").ToString() +"---"+stackPanelButtons.FindResource("keyContent1").ToString();
            txtAboutCompany.TextWrapping = TextWrapping.Wrap;
            this.DataContext = new StackPanel();
            stackPanelButtons.Resources["resBackgroundColour"] = new SolidColorBrush(Colors.Cyan);



        }

        private void btnChnageCompanyName_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Button clicked");
            //Application.Current.FindResource("strCompanyName").Value = "hjj";
            Application.Current.Resources["strCompanyName"] = "Amazon";
            Application.Current.Resources["newCompanyName"] = "Amazon";
            stackPanelButtons.Resources["resBackgroundColour"] = new SolidColorBrush(Colors.Pink);


        }
    }
}
