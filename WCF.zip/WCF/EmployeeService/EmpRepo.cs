﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeService
{
    public class EmpRepo
    {
        List<Employee> empList = new List<Employee>();
        public EmpRepo()
        {
            empList.Add(new Employee(101, "mehta", 45678));
            empList.Add(new Employee(102, "sara", 35678));
            empList.Add(new Employee(103, "lara", 15678));
            empList.Add(new Employee(104, "tara", 25678));
        }

        public List<Employee> returnEmpList()
        {
            return empList;
        }

    }
}