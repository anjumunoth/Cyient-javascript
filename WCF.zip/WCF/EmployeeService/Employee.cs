﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace EmployeeService
{
    [DataContract]
    public class Employee
    {
        [DataMember]
        public int EmpId { get; set; }
        [DataMember]
        public string EmpName { get; set; }
        [DataMember]
        public double Salary { get; set; }

        public Employee(int empId, string empName, double salary)
        {
            EmpId = empId;
            EmpName = empName;
            Salary = salary;
        }

        public override string ToString()
        {
            return $" Employee Id : {EmpId}; Employee Name {EmpName} Salary : {Salary}";
        }
    }
}