﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace SelfHostingExample
{
    [DataContract]
    public class Book
    {
        [DataMember]
        public string BookId { get; set; }

        [DataMember]
        public string BookName { get; set; }

        public Book(string bookId, string bookName)
        {
            BookId = bookId;
            BookName = bookName;
        }

        public override string ToString()
        {
            return $"Book Id : {BookId}; Book Name : {BookName}";
        }
    }
}
