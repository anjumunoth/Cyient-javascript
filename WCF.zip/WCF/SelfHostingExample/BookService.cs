﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace SelfHostingExample
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "BookService" in both code and config file together.
    public class BookService : IBookService
    {
        public List<Book> booksList { get; set; }
        public BookService()
        {
            this.booksList = new List<Book>();
            this.booksList.Add(new Book("101", "Book1"));
            this.booksList.Add(new Book("102", "Book2"));
            this.booksList.Add(new Book("103", "Book3"));
            this.booksList.Add(new Book("104", "Book4"));
        }

        List<Book> IBookService.GetAllBooks()
        {
            return this.booksList;
        }

        bool IBookService.AddBook(Book newBook)
        {
            this.booksList.Add(newBook);
            return true;
        }
    }

}
