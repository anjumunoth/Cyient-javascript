﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WcfFirstServiceConsumer.ServiceReference1;

namespace WcfFirstServiceConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculatorServiceClient proxy = new CalculatorServiceClient();
            int res=proxy.AddTwoNumbers(10, 20);
            Console.WriteLine("The sum of 10 and 20 is " + res);
            Console.ReadLine();
        }
    }
}
