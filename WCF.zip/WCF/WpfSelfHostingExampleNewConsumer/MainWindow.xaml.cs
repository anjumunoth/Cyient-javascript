﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfSelfHostingExampleNewConsumer.ServiceReference1;

namespace WpfSelfHostingExampleNewConsumer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BookServiceClient proxy;
        public MainWindow()
        {
            InitializeComponent();
             proxy= new BookServiceClient();
            lvBookList.ItemsSource = proxy.GetAllBooks();
        }

        private void btnAddBook_Click(object sender, RoutedEventArgs e)
        {
            Book newBook = new Book();
            newBook.BookId = txtBookId.Text;
            newBook.BookName = txtBookName.Text;
            bool res=proxy.AddBook(newBook);
            if (res)
            {
                MessageBox.Show("Book details added successfully");
            }
        }
    }
}
