﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace webapiExample2
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "RootApi",
                routeTemplate: "",
                defaults: new
                {
                    controller="Employee"
                }
                );

            config.Routes.MapHttpRoute(
                name: "SampleApi",
                routeTemplate: "api/example1/{id}",
                defaults:new
                {
                    controller="Sample",
                    id=40
                }
                );

            config.Routes.MapHttpRoute(
                name:"FilterApi",
                routeTemplate:"api/filter/{id}/category/{categoryName}",
                defaults: new
                {
                    controller = "BooksSelection",
                    categoryName = RouteParameter.Optional
                },
                constraints:new {id=@"\d+"}
                );

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
