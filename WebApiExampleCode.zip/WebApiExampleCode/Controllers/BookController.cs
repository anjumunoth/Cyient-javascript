﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using webapiExample2.Models;

namespace webapiExample2.Controllers
{
    public class BookController : ApiController
    {
        //Get api/book -- return a list of books
        public List<Book> bookList { get; set; }
        Book book;
        public BookController()
        {

            book = new Book();

            bookList = new List<Book>(){
                new Book(101,"Book1","Author1",12345,100,"Book1 Description"),
                new Book(102,"Book2","Author2",7410,200,"Book2 Description"),
                new Book(103,"Book3","Author1",15250,300,"Book3 Description"),
                new Book(104,"Book4","Author4",4511,400,"Book4 Description"),
                new Book(105,"Book5","Author5",34511,500,"Book5 Description"),
                new Book(106,"Book6","Author6",34511,600,"Book6 Description"),
                new Book(107,"Book7","Author7",34511,700,"Book7 Description"),
                new Book(108,"Book8","Author8",34511,500,"Book8 Description"),
                new Book(109,"Book9","Author9",34511,500,"Book9 Description"),
                new Book(110,"Book10","Author10",34511,510,"Book10 Description"),
                new Book(111,"Book11","Author11",34511,5000,"Book11 Description"),
                new Book(112,"Book12","Author12",34511,5002,"Book12 Description"),
                new Book(113,"Book13","Author13",34511,5200,"Book13 Description"),
                new Book(114,"Book14","Author14",34511,5030,"Book14 Description"),
                new Book(115,"Book15","Author15",34511,1500,"Book15 Description"),
                new Book(116,"Book16","Author16",34511,3500,"Book16 Description"),
                new Book(117,"Book17","Author17",34511,5300,"Book17 Description"),
                new Book(118,"Book18","Author18",34511,50550,"Book18 Description"),
                new Book(119,"Book19","Author19",34511,5008,"Book19 Description"),
                new Book(120,"Book20","Author20",34511,5090,"Book20 Description")


            };
        }
        //public List<Book> GetAllBooks()
        //{
        //    return bookList;
        //}


        //Get api/Book/101 (Combinations of parameters )
        //public HttpResponseMessage GetParticularBook(int id)
        //{
        //    bool isFound = false;
        //    Book selectedBook = null;
        //    for (int i = 0; i < bookList.Count; i++)
        //    {
        //        if (bookList[i].BookId == id)
        //        {

        //            isFound = true;
        //            selectedBook = bookList[i];
        //        }
        //    }
        //    if (isFound == true)
        //    {
        //        return Request.CreateResponse(HttpStatusCode.OK, selectedBook);
        //    }
        //    else
        //        return Request.CreateResponse(HttpStatusCode.NotFound, id + " Not Found");
        //}

        ////Get api/Book?authorname=Author1(query strings)
        //public IEnumerable<Book> GetAllBookByAuthorName(string authorname)
        //{
        //    return bookList.FindAll(item => item.BookAuthor == authorname).ToList();
        //}


        ////Get api/Book?authorname=Author1&bookname=Book1(Combinations of query strings)
        //public Book GetBookByBookNameAndAuthorName(string authorname, string bookname)
        //{
        //    return bookList.Find(item => ((item.BookAuthor == authorname) && (item.BookName == bookname)));
        //}

        ////Get api/Book/101?authorname=Author1(Combinations of parameters and query strings)
        //public Book GetBookByBookIdAndAuthorName(int id, string authorname)
        //{
        //    return bookList.Find(item => ((item.BookAuthor == authorname) && (item.BookId == id)));
        //}

        [HttpGet]
        public bool CheckIfBookExists(Book b1)
        {
            Book temp = bookList.Find(item => item.BookId == b1.BookId);
            if (temp != null)
            {
                return true;
            }
            else
                return false;

        }

        //handling post request such that entire data comes only in body sections
        //public IHttpActionResult Post(Book b1)
        //{

        //   Book temp=bookList.Find(item=> (item.BookId==b1.BookId));
        //    if(temp==null)
        //    {
        //        bookList.Add(b1);
        //    return Ok(bookList);
        //    }
        //    else
        //        return BadRequest("Book Id is already exist");
        //}

        //Handling POST request that the data comes only in the URL section
        public IHttpActionResult Post(int id, string name, string author, double isbn, double price, string description)
        {
            Book temp = null;
            temp = bookList.Find(item => (item.BookId == id));
            if (temp == null)
            {
                bookList.Add(new Book(id, name, author, isbn, price, description));
                return Ok(bookList);
            }
            else
                return BadRequest("Book Id is already exist");
        }


        //Handling the Post request such that entire data comes only in url section using[FromUri]
        public IHttpActionResult Post([FromUri] Book b11)
        {
            Book temp = bookList.Find(item => (item.BookId == b11.BookId));
            if (temp == null)
            {
                bookList.Add(b11);
                return Ok(bookList);
            }
            else
                return BadRequest("Book Id is already exist");
        }

        //PUT -- api/book/101; body :{book details}

        public IHttpActionResult Put(int id, Book b1)
        {
            Book temp = bookList.Find(item => item.BookId == id);
            if (temp != null)
            {
                
                if(temp.BookId== b1.BookId)
                {
                    temp.BookName = b1.BookName;
                    temp.BookAuthor = b1.BookAuthor;
                    temp.BookPrice = b1.BookPrice;
                    temp.Description = b1.Description;
                    temp.Isbn = b1.Isbn;
                    return Ok(bookList);
                }
                else
                {
                    return BadRequest("Book Id in the request does not match with the data");
                }
                
            }
            else
            {
                return BadRequest("Book Id does not exist to modify");
            }
            
        }


        // Delete -- api/book/101 -- empty body

        public IHttpActionResult Delete(int id)
        {
            int pos=bookList.FindIndex(item => item.BookId == id);
            if(pos >=0)
            {
                bookList.RemoveAt(pos);
                return Ok(bookList);
            }
            else
            {
                return BadRequest("Book Id does not exist to delete");
            }
        }

        // Patch -- api/book/101 -- data body
        //public IHttpActionResult Patch(int id, [FromBody] string bookName)
        //{
        //    Book Temp = bookList.Find(item => item.BookId == id);
        //    if (Temp != null)
        //    {
        //        Temp.BookName = bookName;
        //        return Ok(bookList);
        //    }
        //    else
        //    {
        //        return BadRequest("Book Id does not exist to modify");
        //    }
        //}

        // for a given book id , update the bookname and author name
        public IHttpActionResult Patch(int id,Book b1)
        {
            Book Temp = bookList.Find(item => item.BookId == id);
            if (Temp != null)
            {
                Temp.BookName = b1.BookName;
                Temp.BookAuthor = b1.BookAuthor;
                return Ok(bookList);
            }
            else
            {
                return BadRequest("Book Id does not exist to modify");
            }
        }

        //Will not work
        //public IHttpActionResult Patch(int id,[FromBody]string bookName,[FromBody] string authorName)
        //{
        //    Book Temp = bookList.Find(item => item.BookId == id);
        //    if (Temp != null)
        //    {
        //        Temp.BookName = bookName;
        //        Temp.BookAuthor = authorName;
        //        return Ok(bookList);
        //    }
        //    else
        //    {
        //        return BadRequest("Book Id does not exist to modify");
        //    }
        //}
        // specify it as a non action method
        [NonAction]
        List<Book> getElementsInARange(int startIndex)
        {
            return bookList.GetRange(startIndex, 5);
        }
        [HttpGet]
        public IHttpActionResult SendResultInPages(string pageId)
        {
            /*
             * pageId =1; 0 to 4 elements in bookList
             * pageId =2; 5 to 9 elements in bookList
             * pageId =3; 10 to 14 elements in bookList
             * pageId =4; 15 to 19 elements in bookList
             * 
             */
            switch(pageId)
            {
                case "1":
                    return Ok(getElementsInARange(0));
                    
                case "2":
                    return Ok(getElementsInARange(5));
                    
                case "3": return Ok(getElementsInARange(10));
                case "4": return Ok(getElementsInARange(15));
                default: return Ok(getElementsInARange(0));
            }
        }

        [HttpGet]
        public IHttpActionResult SendResultsAccordingToSortOrder(string sortOrder)
        {
            if(sortOrder =="desc")
            {
                // sort the list in the desc order of price
                List<Book> temp = bookList;
                temp.Sort(new BookComparator());
                //temp.Reverse();will not use the IComparable
                return Ok(temp);
             }
            else
            {
                // sort the list in the asc order of price
                List<Book> temp = bookList;
                temp.Sort();
                return Ok(temp);
            }
            
        }
    }
}

/*
 * Routing 
 * 1. Convention based routing
 * 2. Attribute based routing
 */







