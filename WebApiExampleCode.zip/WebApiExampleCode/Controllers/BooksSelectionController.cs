﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using webapiExample2.Models;

namespace webapiExample2.Controllers
{
    public class BooksSelectionController : ApiController
    {
        public List<Book> bookList { get; set; }
        public BooksSelectionController()
        {
            bookList = new List<Book>()
            {
                new Book(101, "Book1", "Author1", 12345, 100, "Book1 Description"),
                new Book(102, "Book2", "Author2", 7410, 200, "Book2 Description"),
                new Book(103, "Book3", "Author1", 15250, 300, "Book3 Description"),
                new Book(104, "Book4", "Author4", 4511, 400, "Book4 Description"),
                new Book(105, "Book5", "Author5", 34511, 500, "Book5 Description"),
                new Book(106, "Book6", "Author6", 34511, 600, "Book6 Description"),
                new Book(107, "Book7", "Author7", 34511, 700, "Book7 Description"),
                new Book(108, "Book8", "Author8", 34511, 500, "Book8 Description"),
                new Book(109, "Book9", "Author9", 34511, 500, "Book9 Description"),
                new Book(110, "Book10", "Author10", 34511, 510, "Book10 Description"),
                new Book(111, "Book11", "Author11", 34511, 5000, "Book11 Description"),
                new Book(112, "Book12", "Author12", 34511, 5002, "Book12 Description"),
                new Book(113, "Book13", "Author13", 34511, 5200, "Book13 Description"),
                new Book(114, "Book14", "Author14", 34511, 5030, "Book14 Description"),
                new Book(115, "Book15", "Author15", 34511, 1500, "Book15 Description"),
                new Book(116, "Book16", "Author16", 34511, 3500, "Book16 Description"),
                new Book(117, "Book17", "Author17", 34511, 5300, "Book17 Description"),
                new Book(118, "Book18", "Author18", 34511, 50550, "Book18 Description"),
                new Book(119, "Book19", "Author19", 34511, 5008, "Book19 Description"),
                new Book(120, "Book20", "Author20", 34511, 5090, "Book20 Description")

            };
        }

        [HttpGet]
        public IHttpActionResult GetAllBooks()
        {
            return Ok(bookList);
        }

        public HttpResponseMessage GetBookById(int id)
        {
            bool isFound = false;
            Book selectedBook = null;
            for (int i = 0; i < bookList.Count; i++)
            {
                if (bookList[i].BookId == id)
                {

                    isFound = true;
                    selectedBook = bookList[i];
                }
            }
            if (isFound == true)
            {
                return Request.CreateResponse(HttpStatusCode.OK, selectedBook);
            }
            else
                return Request.CreateResponse(HttpStatusCode.NotFound, id + " Not Found");

        }
    }
}
