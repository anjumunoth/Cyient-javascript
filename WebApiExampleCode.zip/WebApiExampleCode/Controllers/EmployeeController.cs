﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using webapiExample2.Models;

namespace webapiExample2.Controllers
{
    public class EmployeeController : ApiController
    {
        Employee emp;
        EmployeeController()
        {
             emp = new Employee(101, "sara", 567.87);
        }
        // get request
        //GET api/employee
        public Employee get()
        {
            return emp; 
        }

        // GET api/employee/aakash
        public HttpResponseMessage GetEmployeeName(int id)
        {
            if (emp.EmpId == id)
            {
                return Request.CreateResponse(HttpStatusCode.OK, emp.EmpName);
                   
            }
            else
                return Request.CreateResponse(HttpStatusCode.NotFound, id);
            
        }

        public IHttpActionResult GetEmployee(double salary)
        {
            if(emp.Salary == salary)
            {
                return Ok(emp);
            }
            else
            {

                return Redirect("https://www.cyient.com/");
                //return RedirectToRoute("api/employee", null);
            }
        }


        // POST api/employee?id=102&empName=tara&salary=1000
        // POST api/employee/102?empName=tara&salary=1000
        // POST api/employee?empName=tara&salary=1000&id=102
        
        //public IHttpActionResult Post(int id, string empName,double salary)
        //{
        //    Employee temp = new Employee(id, empName, salary);
        //    emp = temp;
        //    return Ok(temp);
        //}
        //public IHttpActionResult Post(Employee e1)
        //{
        //    emp = e1;
        //    return Ok(e1);
        //}

        //public IHttpActionResult Post(int id)
        //{
        //    emp=new Employee(id,"asha",6666) ;
        //    return Ok(emp);
        //}

        //public IHttpActionResult Post([FromBody] string name)
        //{
        //    emp = new Employee(111, name, 10000);
        //    return Ok(emp);
        //}

        public IHttpActionResult Post([FromUri]Employee e1)
        {
            return Ok(e1);
        }




    }
}

// Web api action method can have the following return types
/*
 * 1. void
 * 2. Primitive type
 * 3. Complex type 
 * 4. HttpResponseMessage
 * 5. IHttpActionResult
 *  -- OK, NotFound, BadRequest(400), InternalServerExrror(500), Redirect(302), Unauthorised(401)
 */

/*
 * Post
 * 1. Handle post request such that the entire data comes only in the body section
 * 2. Handle post request such that the entire data comes only in the url section
 * 3.  Handle post request such that the entire data comes only in the url section but use the [FromURI]
 * 4. Action,predicate, function delegates
 * 5. Generic collections -- List
 * 
 * 
 */
