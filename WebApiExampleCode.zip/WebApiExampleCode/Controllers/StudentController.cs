﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace webapiExample2.Controllers
{
    public class StudentController : ApiController
    {
        //Get api/student -- default route

        //[Route("api/student/{id}/names")]
        //public IEnumerable<string> getAllStudents(int id)
        //{
        //    List<string> names = new List<string>() { "asha", "sara", "tara" };
        //    return names;
        //}

        [Route("api/student/{id:int?}")]
        public string getAllStudents(int id=0)
        {
            List<string> names = new List<string>() { "asha", "sara", "tara" };
            int rem = id % 3;
            return names[rem];
        }

        [Route("api/student/{name:alpha}")]
        public bool getAllStudents(string name)
        {
            List<string> names = new List<string>() { "asha", "sara", "tara" };
            return names.Contains(name);
            
        }

        

    }
}

// Collections 
