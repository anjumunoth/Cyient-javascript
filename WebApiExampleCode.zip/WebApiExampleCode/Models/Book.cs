﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace webapiExample2.Models
{
    public class Book: IComparable<Book>
    {
        // write fields/properties/ constructor/toString
        //Id, Name, author, ISBN code, description of book, price, bookImage
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string BookAuthor { get; set; }
        public double Isbn { get; set; }
        public double BookPrice { get; set; }
        public string Description { get; set; }

        public Book()
        {
        }
        public Book(int bookId, string bookName, string bookAuthor, double isbn, double bookPrice, string description)
        {
            this.BookId = bookId;
            this.BookName = bookName;
            this.BookAuthor = bookAuthor;
            this.Isbn = isbn;
            this.BookPrice = bookPrice;
            this.Description = description;
        }
        public override string ToString()
        {
            return $"BookId : {BookId}; Book Name : {BookName}; Author : {BookAuthor}; ISBN Code : {Isbn}; Price : {BookPrice}; Description :{Description} ";

        }

        int IComparable<Book>.CompareTo(Book other)
        {
            if (this.BookPrice > other.BookPrice)
                return 1;
            else
                if (this.BookPrice < other.BookPrice)
                return -1;
            else
                return 0;
            
        }
    }

    public class BookComparator : IComparer<Book>
    {
        
        int IComparer<Book>.Compare(Book x, Book y)
        {
            if (x.BookPrice > y.BookPrice)
                return -1;
            else
               if (x.BookPrice < y.BookPrice)
                return 1;
            else
                return 0;
        }
    }

}






