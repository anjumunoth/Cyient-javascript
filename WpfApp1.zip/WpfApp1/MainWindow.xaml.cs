﻿using System;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //System.Collections.Generic.List<string> colours;
            //Grid grid = new Grid();
            //this.Content = grid;
            //// create a button
            //Button b1 = new Button();
            //b1.Content = "Register";
            //b1.HorizontalAlignment = HorizontalAlignment.Left;
            //b1.VerticalAlignment = VerticalAlignment.Top;
            //b1.Margin = new Thickness(150);
            //b1.Width = 100;
            
            //grid.Children.Add(b1);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Button clicked");
        }

        

        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            btn1.Background = Brushes.Pink;
        }

        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            btn1.Background = Brushes.Green;
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            btn1.Background = Brushes.White;

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            btn1.Background = new SolidColorBrush(Colors.Blue);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            btn1.Background = new SolidColorBrush(Color.FromRgb(111,111,111));
        }

        private void Button_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
           
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Left mouse button clicked");
            btn1.Background = Brushes.CadetBlue;
        }
    }
}

/*
 * XAML -- Extensible Application Markup Language
 * Microsoft's version of XML
 * Based on xml
 * 
 * Design the Ui -- GUI
 */
