var empApp=angular.module("empApp",[]);
empApp.controller("secondChildOfEmpDisplayController",function($scope){})
empApp.controller("siblingOfEmpDisplayController",function($scope){})
