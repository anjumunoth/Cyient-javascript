empApp.controller("empEditController",function($scope){
    
})