console.log("hello");
var myApp=angular.module("myApp",[]);
myApp.controller("updateCtrController",
function updateCtrController($scope)
{
    var myCtr=0;// model 
    $scope.ctr=myCtr;
    $scope.subCtrEventHandler=function (){
        $scope.ctr--;
    }
    $scope.addCtrEventHandler=function(){
        $scope.ctr++;
    }
})