var todoApp= angular.module("todoApp",[]);
todoApp.controller("todoDisplayController",function($scope){
    var todoArr=[
        {task:"Finish reading the book", status:false,runningStatus:false},
        {task:"Watch Eternals", status:false,runningStatus:false},
        {task:"Go on a hike", status:false,runningStatus:true},
        {task:"Learn Spanish", status:true,runningStatus:false},
        {task:"Visit Dubai", status:false,runningStatus:false}];

    $scope.todos=todoArr;
    $scope.markAllDoneEventHandler=function(){
        $scope.todos.forEach((item)=>{
            item.status=true;
        })
    }
    
    $scope.markAllRunningEventHandler=function(){
        $scope.todos.forEach((item)=>{
            item.runningStatus=true;
        })
    }
})